const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const path = require('path');
const fs = require('fs').promises;
const nodemailer = require('nodemailer');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

// ========================================
// MIDDLEWARES
// ========================================

// Sécurité
app.use(helmet({
  contentSecurityPolicy: false, // Désactivé pour le développement
}));

// CORS
app.use(cors());

// Parse JSON et URL-encoded bodies
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Fichiers statiques
app.use(express.static(path.join(__dirname, '../public')));

// Rate limiting pour éviter les abus
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // max 100 requêtes par IP
  message: 'Trop de requêtes depuis cette adresse IP, veuillez réessayer plus tard.'
});
app.use('/api/', limiter);

// Rate limiting spécifique pour le formulaire de contact
const contactLimiter = rateLimit({
  windowMs: 60 * 60 * 1000, // 1 heure
  max: 5, // max 5 soumissions par heure
  message: 'Trop de soumissions de formulaire. Veuillez réessayer dans une heure.'
});

// ========================================
// CONFIGURATION EMAIL (Nodemailer)
// ========================================

const transporter = nodemailer.createTransport({
  service: process.env.EMAIL_SERVICE || 'gmail',
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASSWORD
  }
});

// ========================================
// ROUTES API
// ========================================

// Route de test
app.get('/api/health', (req, res) => {
  res.json({ 
    status: 'OK', 
    timestamp: new Date().toISOString(),
    service: 'Agency Leo Services API' 
  });
});

// ========================================
// GESTION DES AVIS CLIENTS
// ========================================

// Récupérer tous les avis
app.get('/api/avis', async (req, res) => {
  try {
    const data = await fs.readFile(
      path.join(__dirname, '../data/avis.json'),
      'utf8'
    );
    const avisData = JSON.parse(data);
    
    // Filtrer uniquement les avis visibles
    const avisVisibles = avisData.avis.filter(avis => avis.visible);
    
    res.json({
      success: true,
      count: avisVisibles.length,
      avis: avisVisibles
    });
  } catch (error) {
    console.error('Erreur lors de la lecture des avis:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Erreur lors de la récupération des avis' 
    });
  }
});

// Récupérer un avis spécifique
app.get('/api/avis/:id', async (req, res) => {
  try {
    const data = await fs.readFile(
      path.join(__dirname, '../data/avis.json'),
      'utf8'
    );
    const avisData = JSON.parse(data);
    const avis = avisData.avis.find(a => a.id === parseInt(req.params.id));
    
    if (!avis) {
      return res.status(404).json({ 
        success: false, 
        message: 'Avis non trouvé' 
      });
    }
    
    res.json({ success: true, avis });
  } catch (error) {
    console.error('Erreur:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Erreur serveur' 
    });
  }
});

// Ajouter un nouvel avis (nécessite authentification dans un vrai système)
app.post('/api/avis', async (req, res) => {
  try {
    const { nom, poste, entreprise, texte, rating } = req.body;
    
    // Validation
    if (!nom || !texte || !rating) {
      return res.status(400).json({ 
        success: false, 
        message: 'Données manquantes' 
      });
    }
    
    const data = await fs.readFile(
      path.join(__dirname, '../data/avis.json'),
      'utf8'
    );
    const avisData = JSON.parse(data);
    
    // Créer nouvel avis
    const nouvelAvis = {
      id: Math.max(...avisData.avis.map(a => a.id)) + 1,
      rating: parseInt(rating),
      nom,
      poste: poste || '',
      entreprise: entreprise || '',
      texte,
      date: new Date().toISOString().split('T')[0],
      visible: false // Nécessite validation admin
    };
    
    avisData.avis.push(nouvelAvis);
    
    await fs.writeFile(
      path.join(__dirname, '../data/avis.json'),
      JSON.stringify(avisData, null, 2)
    );
    
    res.json({ 
      success: true, 
      message: 'Avis enregistré avec succès',
      avis: nouvelAvis 
    });
  } catch (error) {
    console.error('Erreur:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Erreur lors de l\'enregistrement' 
    });
  }
});

// ========================================
// GESTION DES SERVICES/CATALOGUE
// ========================================

// Récupérer tous les services
app.get('/api/services', async (req, res) => {
  try {
    const data = await fs.readFile(
      path.join(__dirname, '../data/services.json'),
      'utf8'
    );
    const servicesData = JSON.parse(data);
    
    // Filtrage optionnel par catégorie
    const { categorie, populaire } = req.query;
    let services = servicesData.services;
    
    if (categorie) {
      services = services.filter(s => s.categorie === categorie);
    }
    
    if (populaire === 'true') {
      services = services.filter(s => s.populaire === true);
    }
    
    res.json({
      success: true,
      count: services.length,
      services
    });
  } catch (error) {
    console.error('Erreur:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Erreur lors de la récupération des services' 
    });
  }
});

// Récupérer un service spécifique
app.get('/api/services/:id', async (req, res) => {
  try {
    const data = await fs.readFile(
      path.join(__dirname, '../data/services.json'),
      'utf8'
    );
    const servicesData = JSON.parse(data);
    const service = servicesData.services.find(s => s.id === parseInt(req.params.id));
    
    if (!service) {
      return res.status(404).json({ 
        success: false, 
        message: 'Service non trouvé' 
      });
    }
    
    res.json({ success: true, service });
  } catch (error) {
    console.error('Erreur:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Erreur serveur' 
    });
  }
});

// ========================================
// FORMULAIRE DE CONTACT
// ========================================

app.post('/api/contact', contactLimiter, async (req, res) => {
  try {
    const { nom, email, telephone, entreprise, message, service } = req.body;
    
    // Validation
    if (!nom || !email || !message) {
      return res.status(400).json({ 
        success: false, 
        message: 'Veuillez remplir tous les champs obligatoires' 
      });
    }
    
    // Validation email
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return res.status(400).json({ 
        success: false, 
        message: 'Email invalide' 
      });
    }
    
    // Sauvegarder dans un fichier de log
    const contactData = {
      timestamp: new Date().toISOString(),
      nom,
      email,
      telephone: telephone || 'Non fourni',
      entreprise: entreprise || 'Non fourni',
      service: service || 'Non spécifié',
      message
    };
    
    // Sauvegarder dans contacts.json
    let contacts = [];
    try {
      const existingData = await fs.readFile(
        path.join(__dirname, '../data/contacts.json'),
        'utf8'
      );
      contacts = JSON.parse(existingData);
    } catch (error) {
      // Fichier n'existe pas encore
      contacts = [];
    }
    
    contacts.push(contactData);
    
    await fs.writeFile(
      path.join(__dirname, '../data/contacts.json'),
      JSON.stringify(contacts, null, 2)
    );
    
    // Envoyer email de notification
    if (process.env.EMAIL_USER && process.env.EMAIL_PASSWORD) {
      const mailOptions = {
        from: process.env.EMAIL_USER,
        to: process.env.NOTIFICATION_EMAIL || process.env.EMAIL_USER,
        subject: `[Agency Leo] Nouveau contact: ${nom}`,
        html: `
          <h2>Nouveau message de contact</h2>
          <p><strong>Nom:</strong> ${nom}</p>
          <p><strong>Email:</strong> ${email}</p>
          <p><strong>Téléphone:</strong> ${telephone || 'Non fourni'}</p>
          <p><strong>Entreprise:</strong> ${entreprise || 'Non fourni'}</p>
          <p><strong>Service intéressé:</strong> ${service || 'Non spécifié'}</p>
          <p><strong>Message:</strong></p>
          <p>${message}</p>
          <hr>
          <p style="color: #666; font-size: 12px;">Reçu le ${new Date().toLocaleString('fr-FR')}</p>
        `
      };
      
      await transporter.sendMail(mailOptions);
      
      // Email de confirmation au client
      const confirmationMail = {
        from: process.env.EMAIL_USER,
        to: email,
        subject: 'Confirmation de votre demande - Agency Leo Services',
        html: `
          <h2>Merci pour votre message !</h2>
          <p>Bonjour ${nom},</p>
          <p>Nous avons bien reçu votre demande et nous vous remercions de l'intérêt que vous portez à nos services.</p>
          <p>Notre équipe reviendra vers vous dans les plus brefs délais (généralement sous 24h ouvrées).</p>
          <br>
          <p><strong>Récapitulatif de votre demande:</strong></p>
          <p>${message}</p>
          <hr>
          <p style="color: #666;">
            <strong>Agency Leo Services</strong><br>
            Votre partenaire en automatisation et IA
          </p>
        `
      };
      
      await transporter.sendMail(confirmationMail);
    }
    
    res.json({ 
      success: true, 
      message: 'Message envoyé avec succès ! Nous vous recontacterons bientôt.' 
    });
    
  } catch (error) {
    console.error('Erreur lors de l\'envoi du formulaire:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Erreur lors de l\'envoi du message. Veuillez réessayer.' 
    });
  }
});

// ========================================
// CHATBOT IA (Simple - à remplacer par OpenAI/Claude)
// ========================================

app.post('/api/chatbot', async (req, res) => {
  try {
    const { message, conversationId } = req.body;
    
    if (!message) {
      return res.status(400).json({ 
        success: false, 
        message: 'Message vide' 
      });
    }
    
    // Réponses pré-programmées simples (à remplacer par une vraie IA)
    const responses = {
      'prix': 'Nos tarifs varient selon vos besoins. Un chatbot commence à 499€/mois. Souhaitez-vous un devis personnalisé ?',
      'services': 'Nous proposons: Chatbots IA, Automatisation, Analyse Prédictive, Sites Web Intelligents, Assistants Vocaux et CRM Intelligent. Quel service vous intéresse ?',
      'contact': 'Vous pouvez nous joindre via le formulaire de contact ou par email. Souhaitez-vous parler à un conseiller ?',
      'demo': 'Excellente idée ! Nous pouvons organiser une démo gratuite. Veuillez remplir le formulaire de contact en précisant "Demande de démo".',
      'bonjour': 'Bonjour ! Je suis l\'assistant virtuel d\'Agency Leo Services. Comment puis-je vous aider aujourd\'hui ?',
      'merci': 'Avec plaisir ! N\'hésitez pas si vous avez d\'autres questions. 😊'
    };
    
    // Détection simple de mots-clés
    const lowerMessage = message.toLowerCase();
    let response = 'Je ne suis pas sûr de comprendre votre question. Pouvez-vous la reformuler ou utiliser le formulaire de contact pour parler à un humain ?';
    
    for (const [key, value] of Object.entries(responses)) {
      if (lowerMessage.includes(key)) {
        response = value;
        break;
      }
    }
    
    res.json({
      success: true,
      response,
      conversationId: conversationId || Date.now().toString()
    });
    
  } catch (error) {
    console.error('Erreur chatbot:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Erreur du chatbot' 
    });
  }
});

// ========================================
// GESTION DES ERREURS 404
// ========================================

app.use((req, res) => {
  res.status(404).json({ 
    success: false, 
    message: 'Route non trouvée' 
  });
});

// ========================================
// DÉMARRAGE DU SERVEUR
// ========================================

app.listen(PORT, () => {
  console.log(`
  ╔═══════════════════════════════════════════╗
  ║  🤖 AGENCY LEO SERVICES - API SERVER     ║
  ║  Port: ${PORT}                              ║
  ║  Environment: ${process.env.NODE_ENV || 'development'}              ║
  ║  Status: ✅ Running                        ║
  ╚═══════════════════════════════════════════╝
  `);
});

module.exports = app;
