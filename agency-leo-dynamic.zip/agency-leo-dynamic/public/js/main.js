// ========================================
// CONFIGURATION API
// ========================================
const API_BASE_URL = window.location.origin + '/api';

// ========================================
// NAVIGATION & BURGER MENU
// ========================================
const burger = document.getElementById('burger');
const navMenu = document.getElementById('navMenu');
const navLinks = document.querySelectorAll('.nav-link');

// Toggle burger menu
burger?.addEventListener('click', () => {
    navMenu.classList.toggle('active');
    burger.classList.toggle('active');
});

// Close menu when clicking on a link
navLinks.forEach(link => {
    link.addEventListener('click', () => {
        navMenu.classList.remove('active');
        burger.classList.remove('active');
    });
});

// Active link on scroll
window.addEventListener('scroll', () => {
    let current = '';
    const sections = document.querySelectorAll('section');
    
    sections.forEach(section => {
        const sectionTop = section.offsetTop;
        const sectionHeight = section.clientHeight;
        
        if (window.scrollY >= sectionTop - 100) {
            current = section.getAttribute('id');
        }
    });
    
    navLinks.forEach(link => {
        link.classList.remove('active');
        if (link.getAttribute('href') === `#${current}`) {
            link.classList.add('active');
        }
    });
});

// ========================================
// CHARGEMENT DES SERVICES (CATALOGUE)
// ========================================
async function loadServices() {
    const servicesGrid = document.getElementById('servicesGrid');
    
    try {
        const response = await fetch(`${API_BASE_URL}/services`);
        const data = await response.json();
        
        if (data.success) {
            displayServices(data.services);
        } else {
            servicesGrid.innerHTML = `
                <div class="error-message">
                    <i class="fas fa-exclamation-triangle"></i>
                    <p>Impossible de charger les services</p>
                </div>
            `;
        }
    } catch (error) {
        console.error('Erreur lors du chargement des services:', error);
        servicesGrid.innerHTML = `
            <div class="error-message">
                <i class="fas fa-exclamation-triangle"></i>
                <p>Erreur de connexion au serveur</p>
            </div>
        `;
    }
}

function displayServices(services) {
    const servicesGrid = document.getElementById('servicesGrid');
    
    if (services.length === 0) {
        servicesGrid.innerHTML = '<p>Aucun service disponible.</p>';
        return;
    }
    
    servicesGrid.innerHTML = services.map(service => `
        <div class="service-card" data-category="${service.categorie}" data-popular="${service.populaire}">
            <div class="service-icon">${service.icon}</div>
            ${service.populaire ? '<span class="service-badge">POPULAIRE</span>' : ''}
            <h3 class="service-title">${service.titre}</h3>
            <p class="service-description">${service.description}</p>
            <ul class="service-features">
                ${service.features.map(feature => `<li>${feature}</li>`).join('')}
            </ul>
            <p class="service-price">${service.prix}</p>
            <button class="btn btn-secondary" onclick="selectService('${service.titre}')">
                <i class="fas fa-arrow-right"></i> En savoir plus
            </button>
        </div>
    `).join('');
}

// Filtres de services
const filterButtons = document.querySelectorAll('.filter-btn');

filterButtons.forEach(button => {
    button.addEventListener('click', () => {
        // Remove active class from all buttons
        filterButtons.forEach(btn => btn.classList.remove('active'));
        button.classList.add('active');
        
        const filterValue = button.getAttribute('data-filter');
        const serviceCards = document.querySelectorAll('.service-card');
        
        serviceCards.forEach(card => {
            if (filterValue === 'all') {
                card.style.display = 'block';
            } else if (filterValue === 'populaire') {
                const isPopular = card.getAttribute('data-popular') === 'true';
                card.style.display = isPopular ? 'block' : 'none';
            } else {
                const category = card.getAttribute('data-category');
                card.style.display = category === filterValue ? 'block' : 'none';
            }
        });
    });
});

// Fonction appelée quand on clique sur "En savoir plus"
function selectService(serviceName) {
    // Scroll vers le formulaire de contact
    document.getElementById('contact').scrollIntoView({ behavior: 'smooth' });
    
    // Pré-remplir le service dans le formulaire
    const serviceSelect = document.getElementById('service');
    if (serviceSelect) {
        const serviceMap = {
            'Chatbot IA Personnalisé': 'chatbot',
            'Automatisation des Processus': 'automatisation',
            'Analyse Prédictive IA': 'analyse',
            'Site Web Intelligent': 'web',
            'Assistant Vocal IA': 'vocal',
            'CRM Intelligent': 'crm'
        };
        
        serviceSelect.value = serviceMap[serviceName] || '';
    }
}

// ========================================
// CHARGEMENT DES AVIS CLIENTS
// ========================================
let currentTestimonialIndex = 0;
let testimonials = [];

async function loadTestimonials() {
    const testimonialsSlider = document.getElementById('testimonialsSlider');
    
    try {
        const response = await fetch(`${API_BASE_URL}/avis`);
        const data = await response.json();
        
        if (data.success) {
            testimonials = data.avis;
            displayTestimonials();
        } else {
            testimonialsSlider.innerHTML = `
                <div class="error-message">
                    <p>Impossible de charger les témoignages</p>
                </div>
            `;
        }
    } catch (error) {
        console.error('Erreur lors du chargement des avis:', error);
        testimonialsSlider.innerHTML = `
            <div class="error-message">
                <p>Erreur de connexion au serveur</p>
            </div>
        `;
    }
}

function displayTestimonials() {
    const testimonialsSlider = document.getElementById('testimonialsSlider');
    
    if (testimonials.length === 0) {
        testimonialsSlider.innerHTML = '<p>Aucun avis disponible.</p>';
        return;
    }
    
    testimonialsSlider.innerHTML = testimonials.map((avis, index) => {
        const stars = '⭐'.repeat(avis.rating);
        const initiales = avis.nom.split(' ').map(n => n[0]).join('');
        
        return `
            <div class="testimonial-card ${index === 0 ? 'active' : ''}" data-index="${index}">
                <div class="testimonial-rating">${stars}</div>
                <p class="testimonial-text">"${avis.texte}"</p>
                <div class="testimonial-author">
                    <div class="author-avatar">${initiales}</div>
                    <div class="author-info">
                        <h4>${avis.nom}</h4>
                        <p>${avis.poste} - ${avis.entreprise}</p>
                    </div>
                </div>
            </div>
        `;
    }).join('');
}

// Navigation dans les témoignages
document.getElementById('prevTestimonial')?.addEventListener('click', () => {
    changeTestimonial(-1);
});

document.getElementById('nextTestimonial')?.addEventListener('click', () => {
    changeTestimonial(1);
});

function changeTestimonial(direction) {
    const cards = document.querySelectorAll('.testimonial-card');
    cards[currentTestimonialIndex].classList.remove('active');
    
    currentTestimonialIndex += direction;
    
    if (currentTestimonialIndex < 0) {
        currentTestimonialIndex = cards.length - 1;
    } else if (currentTestimonialIndex >= cards.length) {
        currentTestimonialIndex = 0;
    }
    
    cards[currentTestimonialIndex].classList.add('active');
}

// Auto-rotation des témoignages (toutes les 6 secondes)
setInterval(() => {
    if (testimonials.length > 1) {
        changeTestimonial(1);
    }
}, 6000);

// ========================================
// FORMULAIRE DE CONTACT
// ========================================
const contactForm = document.getElementById('contactForm');
const formStatus = document.getElementById('formStatus');

contactForm?.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    // Récupérer les données du formulaire
    const formData = {
        nom: document.getElementById('nom').value,
        email: document.getElementById('email').value,
        telephone: document.getElementById('telephone').value,
        entreprise: document.getElementById('entreprise').value,
        service: document.getElementById('service').value,
        message: document.getElementById('message').value
    };
    
    // Désactiver le bouton pendant l'envoi
    const submitButton = contactForm.querySelector('button[type="submit"]');
    const originalButtonText = submitButton.innerHTML;
    submitButton.disabled = true;
    submitButton.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Envoi en cours...';
    
    try {
        const response = await fetch(`${API_BASE_URL}/contact`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(formData)
        });
        
        const data = await response.json();
        
        if (data.success) {
            // Succès
            formStatus.className = 'form-status success';
            formStatus.innerHTML = `
                <i class="fas fa-check-circle"></i> ${data.message}
            `;
            contactForm.reset();
            
            // Masquer le message après 5 secondes
            setTimeout(() => {
                formStatus.style.display = 'none';
            }, 5000);
        } else {
            // Erreur
            formStatus.className = 'form-status error';
            formStatus.innerHTML = `
                <i class="fas fa-exclamation-circle"></i> ${data.message}
            `;
        }
    } catch (error) {
        console.error('Erreur:', error);
        formStatus.className = 'form-status error';
        formStatus.innerHTML = `
            <i class="fas fa-exclamation-circle"></i> 
            Une erreur est survenue. Veuillez réessayer.
        `;
    } finally {
        // Réactiver le bouton
        submitButton.disabled = false;
        submitButton.innerHTML = originalButtonText;
    }
});

// ========================================
// CHATBOT WIDGET
// ========================================
const chatbotButton = document.getElementById('openChatbot');
const chatbotWidget = document.getElementById('chatbotWidget');
const closeChatbot = document.getElementById('closeChatbot');
const chatbotForm = document.getElementById('chatbotForm');
const chatbotInput = document.getElementById('chatbotInput');
const chatbotMessages = document.getElementById('chatbotMessages');

let conversationId = null;

// Ouvrir le chatbot
chatbotButton?.addEventListener('click', () => {
    chatbotWidget.classList.add('active');
    chatbotButton.style.display = 'none';
    // Masquer le badge
    const badge = document.querySelector('.chatbot-badge');
    if (badge) badge.style.display = 'none';
});

// Fermer le chatbot
closeChatbot?.addEventListener('click', () => {
    chatbotWidget.classList.remove('active');
    chatbotButton.style.display = 'flex';
});

// Envoyer un message au chatbot
chatbotForm?.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const message = chatbotInput.value.trim();
    if (!message) return;
    
    // Afficher le message de l'utilisateur
    addChatMessage(message, 'user');
    chatbotInput.value = '';
    
    // Afficher l'indicateur de saisie
    const typingIndicator = addTypingIndicator();
    
    try {
        const response = await fetch(`${API_BASE_URL}/chatbot`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                message,
                conversationId
            })
        });
        
        const data = await response.json();
        
        // Supprimer l'indicateur de saisie
        typingIndicator.remove();
        
        if (data.success) {
            conversationId = data.conversationId;
            addChatMessage(data.response, 'bot');
        } else {
            addChatMessage('Désolé, une erreur est survenue. Pouvez-vous réessayer ?', 'bot');
        }
    } catch (error) {
        console.error('Erreur chatbot:', error);
        typingIndicator.remove();
        addChatMessage('Désolé, je rencontre des difficultés. Veuillez utiliser le formulaire de contact.', 'bot');
    }
});

function addChatMessage(text, sender) {
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${sender}-message`;
    
    if (sender === 'bot') {
        messageDiv.innerHTML = `
            <div class="message-avatar">
                <img src="/images/logo.png" alt="Bot">
            </div>
            <div class="message-content">
                <p>${text}</p>
            </div>
        `;
    } else {
        messageDiv.innerHTML = `
            <div class="message-content">
                <p>${text}</p>
            </div>
        `;
    }
    
    chatbotMessages.appendChild(messageDiv);
    chatbotMessages.scrollTop = chatbotMessages.scrollHeight;
}

function addTypingIndicator() {
    const typingDiv = document.createElement('div');
    typingDiv.className = 'message bot-message typing-indicator';
    typingDiv.innerHTML = `
        <div class="message-avatar">
            <img src="/images/logo.png" alt="Bot">
        </div>
        <div class="message-content">
            <p><i class="fas fa-ellipsis-h"></i> En train d'écrire...</p>
        </div>
    `;
    chatbotMessages.appendChild(typingDiv);
    chatbotMessages.scrollTop = chatbotMessages.scrollHeight;
    return typingDiv;
}

// ========================================
// SUGGESTIONS RAPIDES POUR LE CHATBOT
// ========================================
function addQuickSuggestions() {
    const suggestions = [
        'Quels sont vos tarifs ?',
        'Comment fonctionne votre chatbot ?',
        'Je veux une démo',
        'Contactez-moi'
    ];
    
    const suggestionsDiv = document.createElement('div');
    suggestionsDiv.className = 'quick-suggestions';
    suggestionsDiv.innerHTML = suggestions.map(suggestion => `
        <button class="suggestion-btn" onclick="useSuggestion('${suggestion}')">
            ${suggestion}
        </button>
    `).join('');
    
    chatbotMessages.appendChild(suggestionsDiv);
}

function useSuggestion(text) {
    chatbotInput.value = text;
    chatbotForm.dispatchEvent(new Event('submit'));
}

// ========================================
// ANIMATIONS AU SCROLL
// ========================================
const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -100px 0px'
};

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.style.opacity = '1';
            entry.target.style.transform = 'translateY(0)';
        }
    });
}, observerOptions);

// Observer tous les éléments avec animation
document.querySelectorAll('.service-card, .testimonial-card').forEach(el => {
    el.style.opacity = '0';
    el.style.transform = 'translateY(20px)';
    el.style.transition = 'all 0.6s ease';
    observer.observe(el);
});

// ========================================
// INITIALISATION AU CHARGEMENT DE LA PAGE
// ========================================
document.addEventListener('DOMContentLoaded', () => {
    console.log('🤖 Agency Leo Services - Chargement...');
    
    // Charger les données dynamiques
    loadServices();
    loadTestimonials();
    
    // Ajouter des suggestions au chatbot après un court délai
    setTimeout(() => {
        addQuickSuggestions();
    }, 1000);
    
    console.log('✅ Application initialisée avec succès!');
});

// ========================================
// GESTION DES ERREURS GLOBALES
// ========================================
window.addEventListener('error', (e) => {
    console.error('Erreur globale:', e.error);
});

// ========================================
// SMOOTH SCROLL POUR LES ANCRES
// ========================================
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});

// ========================================
// EXPORT DES FONCTIONS GLOBALES
// ========================================
window.selectService = selectService;
window.useSuggestion = useSuggestion;
